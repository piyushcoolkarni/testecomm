<?php
session_start();
include_once "HeaderHtml.php";
include_once "BodyAddToCart.php";
include_once "html/FooterHtml.html";
